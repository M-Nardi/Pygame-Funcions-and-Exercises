import pygame
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREEN    = (0, 255, 0)
RED      = ( 255, 0, 0)
BLUE     = (0, 0, 255)

pygame.init()

screen = pygame.display.set_mode((800,600))

pygame.display.set_caption("... Mnardi's display ...")

screen.fill(BLACK)


pygame.draw.line(screen, GREEN, [100,100 ], [100, 200], 5)
pygame.draw.line(screen, GREEN, [100,100 ], [200, 100], 5)
pygame.draw.line(screen, GREEN, [100,200 ], [200, 200], 5)
pygame.draw.line(screen, GREEN, [200,100 ], [200, 200], 5)


pygame.display.flip()

pygame.time.delay(5000)

pygame.quit()

