import pygame
import math

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREEN    = (0, 255, 0)
RED      = ( 255, 0, 0)
BLUE     = (0, 0, 255)

pygame.init()

screen = pygame.display.set_mode((800,600))

pygame.display.set_caption("... Mnardi's display ...")

screen.fill(BLACK)

for x in range(-100,100):
    pygame.draw.line(screen, WHITE, [x + 20,x*x + 20], [x+5 + 20,x*x + 20], 5)
    pygame.draw.rect(screen, WHITE, [0, 10, 50, 10000], 2)

pygame.display.flip()

pygame.time.delay(6000)

pygame.quit()
