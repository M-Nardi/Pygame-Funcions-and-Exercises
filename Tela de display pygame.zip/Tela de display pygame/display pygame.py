#importada a biblioteca pygame
import pygame

# Inputs
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREEN    = (0, 255, 0)
RED      = ( 255, 0, 0)
BLUE     = (0, 0, 255)

#inicializa as módulos dessa biblioteca.
pygame.init()

#cria uma janela em modo grafico e cria e devolve uma surface ??
screen = pygame.display.set_mode((800,600))

#define um título na janela com sua mensagem...
pygame.display.set_caption("... Mnardi's display ...")

# Set color...
screen.fill(GREEN)

# Change color...
pygame.display.flip()

#aguarda 5 segundos para fechar a janela 
pygame.time.delay(5000)

# finaliza o pygame e descarrega os recursos alocados
pygame.quit()
